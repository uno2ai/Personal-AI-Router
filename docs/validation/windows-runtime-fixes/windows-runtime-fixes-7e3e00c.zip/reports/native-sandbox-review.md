<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Scoped native Windows sandbox correction review

Reviewed range: `9225e38..7e3e00cdc044565044f24aa8f269e0fcfcc95895`, exactly four changed files, in `<REPO>/.validation/publish`. The implementation report is appended to task-1-report.md under "Native model integration correction".

**Verdict: Accept. No Critical or Important finding, and no additional code correction requested.** This is a bounded review of the native sandbox correction, not a reopening of the accepted whole-branch review.

## Strengths and correctness

- `services/nvpair-codex-worker/appserver.go:81`: the extra `-c` and `windows.sandbox="unelevated"` arguments are separate argv elements, appended only after the non-isolated early return and only on Windows. No shell interpretation, Main configuration import, global setting mutation, or elevated setup invocation is introduced. The observed successful native run provides actual installed-CLI evidence that this argument position is accepted.
- The correction selects the native sandbox implementation while leaving the task policy unchanged. The existing thread start/resume and turn start still request `on-request`; read-only turns still send `readOnly` with `networkAccess:false`, and workspace-write retains its existing bounded writable roots. Interactive approval requests are still declined and become `approval_required`. The diff does not choose unrestricted/external sandboxing or automatically approve an escalation.
- `services/nvpair-codex-worker/appserver_test.go:422`: the regression checks the entire isolated argv sequence and the unchanged non-isolated sequence. The actual Linux execution confirms Unix isolated commands also keep their previous arguments. The dedicated test failed before the Windows setting was added and passed afterward.
- `desktop/tests/e2e/codex-desktop.e2e.test.ts:369`: failure diagnostics select at most 16 journal records and only sequence, entry kind, task state, child/thread presence booleans, and event kind. The corresponding Go producers use operational state/event fields; request contents, handoffs, event metadata, response bodies and stderr are excluded. Presence checks do not print child/thread identities. Temporary approval command classification is absent from the final production code.
- `services/nvpair-codex-worker/README.md:54`: the new explanation accurately describes selecting the restricted-token implementation for an isolated home and explicitly records its weaker network isolation. Official OpenAI documentation confirms that unelevated mode uses a restricted token and ACL boundaries with environment-level offline controls, while elevated mode provides the stronger dedicated-user/firewall boundary. It also documents enterprise restrictions on permitted implementations. The README does not claim equivalence to elevated isolation. [Official Windows sandbox documentation](https://learn.chatgpt.com/docs/windows/windows-sandbox), checked 2026-09-08.

The mode is deliberately chosen to support the authorized native Windows environment without machine-wide privileged setup. The existing unreleased Worker patch version remains `0.1.1` per the controller's release decision; this does not require another version increment within the same unreleased repair branch.

## Evidence inspected

- `native-debug-01-journal.log`: failed native task reaches running, then waiting_approval and blocked; it is not a readiness timeout or child crash.
- `native-debug-02-approval.log`: temporary diagnostic classification identifies command-execution approval for the read-only git-status operation. This diagnostic code and event metadata are not retained in the commit.
- `native-debug-03-argv-red.log`: the new regression fails against the missing sandbox argument.
- `native-debug-04-argv-green.log`: the same regression passes with the explicit Windows setting.
- `native-debug-05-sandbox-native.log`: actual native Worker/Supervisor path succeeds; two tests pass and the macOS-only ownership test skips, duration 17.835s. As the report explains, this uses the newly built Worker with the earlier packaged broker/Supervisor in a separate diagnostic binary directory. It is not final installer verification.
- `native-debug-06-worker-full.log`: full native Windows Worker module `count=1` passes, 6.335s. The log is a compact package result; it is not a fresh skip-count audit.
- `native-debug-10-linux-argv-executed.log`: both isolated-argument and extension-isolation tests pass under WSL Ubuntu with explicit exit 0. This is the authoritative captured execution log; the earlier transcript-only file is not substituted for it.
- `native-debug-08-typecheck.log`: all three Desktop TypeScript targets complete, including the changed E2E source.
- Independently ran `git diff --check 9225e38..7e3e00c` successfully and inspected the signed commit. The controller's concurrent build had generated modifications outside these four files; this reviewer left them untouched and does not claim the whole checkout was clean during the build.

## Assessment and limits

**Ready for final packaged native verification: Yes.** The fix directly addresses the observed Windows sandbox-selection failure while preserving the adapter's approval handling and requested task limits. Native unelevated execution retains the documented weaker network boundary; this review does not claim a penetration test of that sandbox or elevate its guarantees beyond OpenAI's documentation.

The controller must complete the new installer build and repeat native E2E against its final packaged binaries. No passing result for those pending gates is claimed here. Native macOS, Windows arm64, and the macOS-only packaged Electron ownership scenario remain outside this scoped evidence. No native process, build, test suite, source/index/HEAD mutation, or subagent was launched by this reviewer; only this report was written outside the publication checkout. Main merge remains the user's decision.
