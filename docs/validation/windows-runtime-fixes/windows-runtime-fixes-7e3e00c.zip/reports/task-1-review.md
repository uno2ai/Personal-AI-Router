<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 1 review: Windows Go runtime

Reviewed commit `5ef8a22` against `538cdfe` in `<REPO>/.validation/publish`, including the Task 1 brief, implementation report, production call sites, and new regression tests. Review was read-only apart from this report. No production files were modified, no agents were spawned, and no full cross-process suite was run.

Verdict: **request changes** for two Important security-boundary defects. The mutex, native executable resolution, and suspended process/job changes otherwise look consistent with the requested repair.

## Important findings

### P1: Validate existing ancestors before protecting or writing through a path

Location: `services/shared/protectedfile/protectedfile.go:23-28` (also `protection_windows.go:14-26`).

`EnsureDir` recurses only when its parent does not exist. For an existing target it inspects only the target, and Windows `checkPath` checks only the final component's attributes. Consequently `EnsureDir(C:/fixture/link/private)` succeeds when `link` is an existing directory junction to another tree and `private` itself is an ordinary directory; `WriteFile(C:/fixture/link/private/credential.json, ...)` then protects and writes in that other tree. The same omission affects read-side `Check` calls when an intermediate ancestor is a junction. An existing ancestor writable or replaceable by another user is also never checked, allowing that user to redirect the path between the named-path protection and subsequent open/write operations. A private final DACL does not establish a trusted path to that final object.

The fresh-directory case compounds this: `os.Mkdir` initially inherits its existing parent's ACL on Windows, and the explicit private DACL is installed only afterward. Under a broadly writable existing parent, another user can obtain a handle during that interval; narrowing a DACL afterward does not revoke already granted handles. Thus the comment that missing ancestors are created privately is stronger than the implementation.

Required repair: validate the existing path ancestry to an appropriate trusted boundary and reject reparse traversal and untrusted replacement rights without chmod/ACL-changing unrelated existing ancestors. Create new Windows directories with the intended security descriptor at creation, or ensure their parent is already trustworthy and private before creation. Ensure read-side protected-path checks use the same safe path policy. Add regression cases for an existing intermediate junction and a broad existing parent, including an assertion that rejected writes leave both the requested and redirected destinations untouched. Current tests cover only missing private/nested directories under a trusted test temp directory, not these cases.

This is a static code finding; no junction or other-user fixture was created during this read-only review.

### P1: Reject an untrusted owner before claiming an existing object is protected

Location: `services/shared/protectedfile/protection_windows.go:38-54`, especially line 54.

`Protect` only changes `DACL_SECURITY_INFORMATION`; it does not inspect or change the owner. The owner check is isolated in `Check`, but `EnsureDir`, `WriteFile`, `NewJournal`, and `OpenTaskIndex` rely on successful `Protect` without subsequently checking ownership. A concrete trigger is an existing journal or task-index file owned by another non-administrator user whose initial DACL grants the Worker user full control. `NewJournal`/`OpenTaskIndex` open that file, `Protect` successfully installs the current-user/SYSTEM/Administrators DACL while retaining the other user's ownership, and the service later appends sensitive task state. That owner can change the DACL back and read the file. Likewise, protecting an existing directory owned by another user does not remove that user's ability to change its access policy. `Check` itself would reject the resulting object, demonstrating that the write and read helpers disagree about the promised protection invariant.

Required repair: reject untrusted owners in `Protect` before modifying any existing object and verify the resulting protection before data is written (or explicitly establish trusted ownership if that is the chosen supported policy). Apply the invariant to existing target directories and files, not just newly created staging files. Add a real Windows owner fixture proving that an untrusted owner cannot make `EnsureDir`/`Protect`/journal or index open succeed and that no new data is appended. The current broad/null-DACL tests all keep a trusted owner, so they do not catch this.

Windows owner/DACL behavior is documented in Microsoft's [ownership example](https://devblogs.microsoft.com/oldnewthing/20241030-00/?p=110440) and [standard access rights](https://learn.microsoft.com/en-us/windows/win32/secauthz/standard-access-rights). This review did not create another account or change object ownership; the triggering case is derived from the explicit owner omission and the documented Windows access model.

## Minor issues and test improvements

- `services/nvpair-codex-worker/executable_windows_test.go:15-38` covers only the nested npm optional package layout. The production resolver also supports the hoisted layout and has a specific actionable missing-native error; add table cases for those two outcomes when updating this area. Existing spaces/ampersand fixtures and unsupported-script rejection are useful.
- `services/nvpair-codex-worker/child_process_windows_test.go:18-80` meaningfully proves that the child cannot execute before assignment and that job close kills both child and descendant. It does not exercise assignment/resume failure cleanup. Inspection shows both production callers invoke `terminateAndWait` and cleanup on verification errors, and the assigned-job map is removed by termination; I found no concrete defect in that path. A focused failure fixture would make the cleanup claim more durable, but this is not a separate release blocker.

## Spec and quality assessment

- Windows ACL checks reject broad ordinary allow ACEs, null DACLs, unsupported ACE types, and final reparse points; staged secret files receive a private DACL before data writes. The two findings above limit the overall safety claim.
- Unix mode enforcement remains present and the new helpers continue using 0700 directories / 0600 files; no weakening of the prior Unix group/world check was found. Native Unix execution was not run by this reviewer.
- The named mutex helper acquires, waits, releases, and closes on one locked OS thread. Cross-goroutine Close waits for completion and is idempotent. Error/contended paths close the handle. Abandoned ownership is treated as successful acquisition and the regression retains a handle so the abandoned kernel object actually survives its prior owner.
- Workspace lease names now hash the existing volume/file identity directly, avoiding current-directory dependence. Journal and index names retain their existing normalized path identity.
- Windows child creation uses CREATE_SUSPENDED, assigns the process to a kill-on-close job, then resumes it. Handles opened during assignment and Toolhelp enumeration are closed; preparation/start/verification failure callers were inspected. No concrete new child cleanup defect found.
- Windows npm shims are treated as installation locators and never interpreted as shell text. Both managed startup and direct AppServerFactory commands resolve to native executables; arguments remain structured exec.Command arguments. Rejecting unsupported layouts produces an actionable native-path/reinstall error, which the brief permits.
- Broker absolute-path fixture and test process cleanup changes are appropriate. Cleanup is registered immediately after successful Start; a shared sync.Once prevents duplicate Wait during explicit restart and t.Cleanup. Tests terminate only their retained process handles. The independent-worker test checks reachability across managed restart and shutdown; it is not claimed as an Electron UI ownership test.
- Fake app-server config/read response matches the expected production isolation probe sufficiently for the fixture and preserves that production check. No discovery or network behavior change appears in the commit.
- No new dependency or JSON-RPC contract change found.

## Verification performed by this reviewer

- `go test ./protectedfile ./winmutex` in `services/shared`: PASS (protectedfile cache hit; winmutex 0.355s).
- `go test ./... -run 'TestWorkspaceLeaseReleaseFromDifferentThread|TestWindowsChildCannotRunBeforeJobAssignment|TestResolveWindowsCodexNPMShims|TestRejectUnsupportedWindowsCodexScript' -count=1` in `services/nvpair-codex-worker`: PASS, 0.917s.
- Implementation report records broader Worker/Supervisor/broker module runs and seven Codex cross-process cases. Those were read as supplied evidence, not independently rerun during review.

## Version dependencies

Controller should patch-bump `nvpair-codex-worker` and `nvpair-codex-supervisor`. Include `nvpair-ui-broker` in the dependency/build inventory because it imports changed shared `codexruntime`, which now imports `protectedfile`. A source import search found no other production services directly importing the changed `codexruntime`, `protectedfile`, or `winmutex` packages. Version updates are explicitly deferred to the controller and are not a review defect in this intermediate commit.
