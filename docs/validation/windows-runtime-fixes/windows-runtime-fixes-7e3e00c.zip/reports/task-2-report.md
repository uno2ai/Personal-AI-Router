<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 2 Windows Desktop protection report

Worktree: `<REPO>/.validation/publish`; branch `codex/windows-runtime-fixes`.
Base for this focused change: `8eccc1d` (controller's version/plan commit after accepted Task1).
Signed focused commit: `5b3a8aa3f1e9ef9c1837af5d6357a5fe036044d2`; sign-off matches author. Worktree clean after commit; not pushed.

## Delivered

- Added broker one-shot `--protected-file read|read-owned-input|write --protected-path <absolute-path>` before logger setup and worker supervision. Reads/writes are capped at 4 MiB. Writes accept stdin only; successful reads return only bytes; errors are fixed metadata-only messages. Exit3 distinguishes absent read input. No JSON-RPC surface or dependencies added.
- Desktop uses a structured, hidden, 15-second bounded broker invocation. Missing/failed helper errors direct users to rebuild/reinstall; no unsafe fallback. Extracted the existing canonical cli-bin resolver to avoid a supervisor/config circular import.
- Managed config, runtime descriptor and supervisor registry reads use strict protected reads. Config, Worker config, Main config and backup writes use private native staging. Main preview/registration reads use the explicitly separate owned-input reader without modifying inherited ACLs. Main registration preserves unrelated entries and the existing fingerprint guard; backup bytes come from the same read as the content transformation.
- With controller approval, added shared `OpenOwnedInput`: Windows uses the existing pinned chain and actual-handle owner/reparse checks without weakening `Open`; Unix checks the opened regular file's owner and final symlink without changing parent modes. Added shared `WriteFilePreservingParent`: Windows delegates existing private WriteFile; Unix factors existing atomic staging once and preserves existing parent modes, creates missing directories0700 and files0600. Existing strict WriteFile behavior is unchanged.
- Native E2E fixtures use the same Desktop writer with their explicitly selected broker build. Extracted bounded JSON-line harness with early event queue, prompt exit/spawn/parse failures, no stderr or response body dumps, and bounded cleanup of owned processes. Native parser and assertions avoid dumping model responses, and E2E source now participates in typecheck. macOS-only packaged Electron restart coverage remains explicitly skipped on Windows.
- Replaced mode-bit-only Windows assertions with actual DACL inspection. Added inherited Main input preservation, strict managed input rejection, spaces/metacharacters, missing helper, limits, junction escape, and early-event/error/cleanup tests. Windows E2E user-data escape uses unprivileged junctions.
- Removed the four reported unused Codex exports/wrapper. New files carry SPDX headers. No dependency installation or junction metadata mutation; no installed Main Codex/account config touched; no build/native model E2E/push performed.

## Verification

Commands used Node26.0.0/npm11.12.1 by prepending the supplied Node directory. Go1.26.4 was used. Logs are under `<REPO>/.validation/fix-logs/`.

| Gate | Result | Log |
| --- | --- | --- |
| Full Desktop unit | 238 passed, 2 skipped, 0 failed; 45 files | task2-unit-verified.log |
| Desktop typecheck node/web/test | all passed; test target includes native Codex E2E | task2-typecheck-verified.log |
| Desktop lint | exit0, 0 errors, 25 existing formatting warnings outside changed files | task2-lint-verified.log |
| Desktop service-contracts:check | passed, generated docs fresh, no drift | task2-contracts-final.log |
| Desktop dead-code:check | passed; zero unused files/exports/types/dependencies/strict findings | task2-dead-code-final.log |
| Broker go test -v ./... | 169 top-level passes, 1 skip, 0 failures across 3 packages | task2-broker-final.log |
| Windows shared protectedfile | 12 top-level passes, 2 explicit capability skips, 0 failures | task2-protectedfile-final.log |
| Linux shared protectedfile under WSL Ubuntu | 5 passed, 0 skipped/failed | task2-unix-green.log |
| SPDX repository check | 986 checked, 0 missing/review/unclassified (99 policy exclusions) | task2-spdx-final.log |
| git diff --check | passed | terminal verification |

The two Desktop skips are existing Unix app-data wipe cases. The broker skip is `TestWaitForStdinCloseKillsWorkerThatIgnoresShutdown`, which requires a POSIX shell. Windows protectedfile skips are the existing `TestWindowsRejectsUntrustedOwnerBeforeProtection` and new `TestWindowsOwnedInputRejectsForeignOwner`; this token cannot assign a foreign SID owner. They remain untested live foreign-owner paths, not passes; deterministic descriptor owner rejection is covered by the existing passing test.

WSL execution used a Linux/amd64 CGO-disabled Go test binary crosscompiled on Windows, then executed under Ubuntu against Linux `/tmp`. It was not merely a crosscompile. macOS execution was not performed.

## Regression evidence and iteration history

- `task2-helper-red.log`: original broker rejects the new flag; green real-binary roundtrip, permissions, limits and failure cleanup recorded in `task2-helper-green.log`, then full broker final run.
- `task2-native-process-red.log`: both early-event and exit diagnostics regressions fail against the original extracted harness; `task2-native-process-green.log` passes, then the full unit run includes six harness tests.
- `task2-desktop-red.log` and early ACL green attempts exposed a PowerShell module autoload issue in the test inspector, so they are not sufficient DACL regression evidence. The inspector now uses the installed Windows PowerShell .NET read-only security API. `task2-desktop-verified-red.log` re-ran the final native security tests against the original three Desktop source files from HEAD: 5 failed and 6 passed for the intended ACL/junction/managed-read defects. Current source was restored in a finally block. Corrected green is `task2-desktop-green-5.log`; final complete suite is above.
- `task2-unix-red.log`: the preserving-parent entrypoint initially delegating to the original strict writer fails the parent0755 regression. Factored shared policy produces all5 Linux tests passing in `task2-unix-green.log`.
- All intermediate logs were retained, including initial typecheck test-alias configuration errors, two command working-directory mistakes, the ACL module diagnostic, and formatting attempts. None replace the verified final results.

## Remaining controller work

Independent scoped review of this focused commit; final build/all-module checks and real native model E2E; publication log redaction, signed release evidence and branch push. Controller owns service versions and the implementation plan, which this change leaves unstaged. No merge to main.
