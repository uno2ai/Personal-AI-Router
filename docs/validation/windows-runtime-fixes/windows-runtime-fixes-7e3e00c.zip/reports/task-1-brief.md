<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Windows runtime fixes implementation plan

**Goal:** Correct the Windows failures recorded for 5fd4f72 and publish a reviewed branch with native verification evidence.

**Architecture:** Go services remain authoritative for credential protection, executable selection and process ownership. Windows ACL validation replaces Unix mode inspection on Windows without weakening Unix protections. Cross-platform tests use real platform paths and explicit resource cleanup. Discovery diagnostics isolate the network before any production discovery change.

**Spec:** User-approved Windows repair scope, captured below; baseline evidence is [the Windows validation report](../../validation/windows-5fd4f72/README.md).

**Tech stack:** Go >=1.25, Node >=25.5, Electron/TypeScript, Windows ACL and process APIs. No new dependencies, no protocol changes unless every relay/consumer is updated, no timeout increases to mask failures. Keep original checkout modifications intact. Sign off commits and push only the repair branch. Main merge and macOS regression testing belong to the user.

## Task 1: Go native runtime and protected files

Files: services/shared (new focused Windows/Unix protection helpers if needed), services/nvpair-codex-worker, services/nvpair-codex-supervisor, services/nvpair-ui-broker/codexworker_test.go, services/tests/codex_supervisor_test.go.

- [ ] Reproduce the existing Supervisor/Worker/broker failures; retain command output.
- [ ] Add regression coverage for actual Windows ACL rejection of broad access and acceptance of protected files; Unix modes must stay enforced.
- [ ] Protect worker config, credentials, isolated authentication and parent directories before secret writes; do not treat chmod on Windows as protection.
- [ ] Fix mutex ownership and handle release with deterministic cross-thread/process contention tests, including release/reacquire and abandoned-owner recovery.
- [ ] Resolve Windows npm Codex shims to the installed native executable or reject unsupported invocation with an actionable error; preserve argument boundaries and avoid arbitrary shell interpretation.
- [ ] Fix Windows test absolute paths and owned-process shutdown; preserve independently owned workers.
- [ ] Run the affected Go module tests and Codex cross-process tests; report exact evidence, any remaining failure, and affected service versions to bump.


