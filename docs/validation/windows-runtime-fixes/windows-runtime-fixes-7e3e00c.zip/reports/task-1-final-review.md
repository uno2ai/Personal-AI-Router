<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 1 final scoped review

Verdict: **accept the Task 1 correction**. No concrete unresolved Important/Critical finding remains within this scoped check.

Reviewed `3f0c299` against its parent `dec8ea2`, limited to the two blockers in task-1-rereview.md and stored-artifact read consistency. The intervening root SPDX metadata commit was not part of this review. No production files were edited, no subagents were spawned, and no additional competing test suite was run.

## Resolution of previous findings

- **Windows inheritance exposure: resolved.** checkSecurity now requires SE_DACL_PROTECTED before accepting the owner/ACE-protected object. Existing inheritable files are rejected by Check, Open, and OpenAppend, rather than narrowed before use. The new regression recreates the previously confirmed parent WRITE_DAC case, verifies rejection of the initially private but inheritable file, then verifies a freshly replaced protected file stays private while its parent gains an inheritable Everyone grant and its append handle remains open. This directly covers the reported defect.
- **Unix missing-parent first use: resolved.** Each Unix filesystem-lock helper now prepares its parent before opening the .lock file. Windows helpers remain unchanged, so the repair does not restore the unsafe Windows pre-append DACL narrowing. Both constructors have nested missing-parent regressions. The supplied WSL execution logs show these tests passing on Linux, together with the existing Journal and TaskIndex regressions; this is actual Linux execution evidence, not merely successful compilation.
- **Stored-artifact read consistency: resolved.** ArtifactStore.Read now uses protectedfile.Open, retains that File during reading, and obtains its size from that actual opened file. The user-workspace source opener is unchanged. The new native Windows artifact test proves a private stored file is readable and the same file is rejected after broadening its ACL.

## Evidence inspected

Read the appended task-1-report.md and the following logs directly:

- task1-fix2-inheritance-green.log: targeted inheritance regression and protectedfile suite PASS.
- task1-fix2-worker-wsl-journal-final.log: all 5 selected Journal tests PASS, including missing-parent first use.
- task1-fix2-supervisor-wsl-taskindex-final.log: all 5 selected TaskIndex tests PASS, including missing-parent first use and concurrent-open rejection.
- task1-fix2-artifact-green.log: stored-artifact ACL rejection and Windows Journal missing-parent tests PASS.
- task1-fix2-worker-final.log: native Windows Worker module PASS, 6.170s.
- task1-fix2-supervisor-final.log: native Windows Supervisor module PASS, 0.611s.
- task1-fix2-shared-final.log: native Windows protectedfile and codexruntime PASS, 0.289s and 0.303s.

The existing live foreign-owner fixture remains an explicit capability skip (ERROR_INVALID_OWNER); this review does not claim live foreign-owner filesystem coverage. The native foreign-owner descriptor mutation-boundary test is passing. Native macOS and Windows arm64 execution remain outside the evidence. The controller retains responsibility for the final integration matrix, Desktop/broker helper, native Codex integration, version bumps, and publication.

No change to the prior affected-service inventory: nvpair-codex-worker, nvpair-codex-supervisor, and nvpair-ui-broker as a changed shared-package consumer.
