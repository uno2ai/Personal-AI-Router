<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Final independent whole-branch review

Reviewed source range: `538cdfe..5b3a8aa3f1e9ef9c1837af5d6357a5fe036044d2`, in `<REPO>/.validation/publish`.

**Verdict: Accept the reviewed source for final controller verification and repair-branch publication. No unresolved Critical or Important finding.** The two Minor test gaps below do not require production changes or block publication for the user's macOS review. This verdict does not claim the pending final integration runs passed and does not authorize a main merge.

## Strengths

- Windows protected I/O creates private objects before writing bytes, opens each component relative to a retained directory handle, rejects actual-handle reparse points, and denies delete sharing for the operation lifetime. The owner and protected-DACL checks are applied to opened managed files. Existing broad append files are rejected without narrowing their ACL or changing their contents. Publication and failed-stage disposal use the retained native handles.
- The Desktop helper reuses these Go guarantees through the canonical bundled broker, with structured arguments, bounded stdin/stdout, hidden creation and fixed diagnostics. The helper dispatch precedes logging and supervision. Strict managed reads remain distinct from owner-checked external Main input, and backups derive from the same input snapshot as the registration transformation. There is no new JSON-RPC contract, native security duplication in TypeScript, or fallback launcher.
- Windows mutex ownership and release stay on a dedicated locked OS thread, including abandoned-owner recovery. App-server children start suspended, join a kill-on-close Job Object, then resume; the callers terminate and wait on verification failure. Normal child and descendant termination have real Windows subprocess coverage.
- Unix file modes remain enforced. The Desktop writer preserves existing containing-directory modes, while new parents are private; the explicit owned-input reader supports ordinary external configuration. Missing-parent Journal/TaskIndex regressions and sticky/intermediate-symlink traversal compatibility have actual WSL Linux execution evidence.
- Native E2E failures retain process metadata rather than response bodies or stderr. The harness retains early events, handles spawn/exit/parse failures, bounds pending output/records, and gives fixture-owned processes bounded shutdown. The separate managed restart test checks an independent Worker stays reachable.
- Version bumps cover every production consumer of the changed shared packages: Worker `0.1.1`, Supervisor `0.1.1`, broker `0.40.3`. Other source changes are focused test support, docs or baseline SPDX repair. All six commits have sign-offs. `git diff 538cdfe..5b3a8aa --check` passes, and the inspected checkout is clean.

## Issues — consolidated list

### Critical / Important

None identified in the reviewed change.

### Minor — nonblocking test coverage

1. **Native npm resolver lacks hoisted-layout and missing-native fixtures.**
   - File: `services/nvpair-codex-worker/executable_windows_test.go:15`; corresponding implementation: `services/nvpair-codex-worker/executable_windows.go:34`.
   - Trigger: npm places the optional platform package directly under the shim's `node_modules`, or the optional package is absent.
   - Assessment: the production loop handles nested and hoisted candidates, and its missing-native path returns an actionable error. The current regression only constructs the nested layout and checks `.cmd`/`.ps1` resolution; the unsupported-script test is a separate case. Static review found no implementation defect, and the installed nested layout has native evidence.
   - Follow-up: table-drive the fixture over both supported layouts, then assert that an absent native package returns the expected actionable error without executing the shim. This is a test-only follow-up, not a request for a new resolution path.

2. **Job assignment/resume failure cleanup lacks a dedicated injected-failure regression.**
   - File: `services/nvpair-codex-worker/child_process_windows_test.go:20`; corresponding implementation: `services/nvpair-codex-worker/child_process_windows.go:44`.
   - Trigger: `OpenProcess`, `AssignProcessToJobObject`, or resuming the suspended primary thread fails after `cmd.Start` succeeds.
   - Assessment: both app-server callers route a failed verification through `terminateAndWait` and cleanup. Before attachment, cleanup closes the unowned job and the caller kills the suspended process; after attachment, termination removes/closes the recorded job. The normal suspended-start/descendant-kill test is substantive, but does not execute these failure branches. No concrete leaked-process defect was found by tracing them.
   - Follow-up: add a narrow deterministic failure seam or an equivalent fixture for assignment and resume failures; assert the suspended child exits, the job handle is released, and no descendant survives. Keep this separate from global process termination.

## Plan alignment and scope

The implementation matches Tasks 1 and 2 and the justified Task 3 scope. The explicit external-input and Unix parent-preserving APIs are cohesive additions needed by Desktop integration. No discovery production change or timeout increase was introduced after the isolated discovery rerun passed. The previous review blockers concerning reparse traversal, owner validation, DACL inheritance, Unix first use, and stored-artifact reads are resolved in this net diff; this review does not reopen them. Unrelated baseline behavior was not converted into repair-branch findings.

The plan's remaining Task 2/3 checkboxes and publication evidence need the controller's documentation closeout after final verification. They are not evidence that the already-reviewed implementation is missing.

## Evidence inspected and explicit limits

Read the senior reviewer template, CONTRIBUTING.md, Developer Guide, Windows repair plan, ledger, both task reports and accepted scoped reviews. Inspected the complete changed implementation, regression tests and relevant callers in passes; checked shared-package consumers and service versions. No subagents, production edits, index/HEAD changes, additional service/network suite, or model E2E was run by this reviewer. The sole written artifact is this report outside the publication checkout.

Directly inspected log evidence includes:

- `task2-unit-verified.log`: 45 files passed, 238 tests passed, 2 skipped; includes 12 Codex config and 6 native-process tests.
- `task2-typecheck-verified.log`, `task2-lint-verified.log`, `task2-dead-code-final.log`, `task2-contracts-final.log`: three TypeScript targets complete, lint 0 errors/25 existing warnings, no dead code, fresh contracts/no drift.
- `task2-protectedfile-final.log`: native Windows protection tests pass, including inherited-input preservation and DACL inheritance rejection; the two live foreign-owner fixtures explicitly skip because this token cannot assign the foreign owner. The native descriptor mutation-boundary owner-rejection test passes. The final log reports the package result as cached; earlier focused native regression logs and reports are retained by the controller.
- `task2-unix-green.log`: all 5 selected shared-protection tests pass under WSL Ubuntu.
- `task1-fix2-worker-wsl-journal-final.log` and `task1-fix2-supervisor-wsl-taskindex-final.log`: all 5 selected tests in each pass under WSL, including missing-parent first use.
- `task1-fix2-worker-final.log` and `task1-fix2-supervisor-final.log`: native full-module passes, 6.170s and 0.611s respectively. `task2-broker-final.log` reports passing broker package results; its report explicitly retains the POSIX-shell-only skip.
- `task1-fix1-cross-process-final.log`: all seven selected Codex cross-process tests pass, including independent Worker preservation (13.809s including builds). This is earlier focused evidence, not a substitute for the controller's final candidate matrix.

At report creation, the controller's full 18-module Go candidate run at `5b3a8aa`, final Desktop checks, Windows x64 package, and packaged native Codex model task are pending. No passing result is claimed for those runs. Native macOS, Windows arm64, live foreign-owner filesystem operations, and the macOS-only packaged Electron restart scenario remain outside the verified Windows evidence. The WSL runs are actual Linux execution of crosscompiled tests, not native macOS execution or a full Linux matrix. Skips remain untested coverage.

## Assessment

**Ready to merge? With final verification and the user's macOS review.** The reviewed source has no identified blocking defect and may proceed through the authorized repair-branch publication workflow after the controller confirms the remaining gates and redacts evidence. Main integration remains the user's decision; any subsequent production-source change requires review of that final source.
