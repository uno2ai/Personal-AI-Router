<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 1 scoped rereview

Reviewed correction `e4233f8` over `5ef8a22` in `<REPO>/.validation/publish`, limited to the original ancestor/reparse and untrusted-owner findings and direct correction interactions. No production edits or subagents. Root-owned versions and plan files were not reviewed as part of this correction.

Verdict: **request changes for two Important findings**. The correction otherwise addresses the original findings substantially: Windows opens one relative component at a time with NtCreateFile RootDirectory, checks reparse attributes on the actual handle, pins the traversal chain through I/O and publication, creates files/directories using a private security descriptor, and checks an existing target owner's SID before security mutation. Config and credential readers now consume the checked file handle. New tests cover junction rejection, replacement attempts, preexisting deletion handles, broad append-file rejection, and private stage cleanup.

## Important findings

### P1: Require a stable private DACL on existing protected files

Location: `services/shared/protectedfile/protection_windows.go:42-55`; consumed by `services/shared/protectedfile/files_windows.go:202-211` in OpenAppend and by Open's handle validation.

`checkSecurity` validates only the current ACEs and owner. It accepts a file whose DACL is currently private but is not marked SE_DACL_PROTECTED. Because the new traversal design deliberately permits public containing directories, an identity with WRITE_DAC on that parent can add an inheritable grant later. Windows propagates that grant onto an unprotected child even while its handles and directory chain are pinned. An accepted journal/task-index handle then continues appending into a file now readable by that identity. No rename or path race is needed.

This was reproduced natively using the scratch fixture `<REPO>/.validation/fix-reports/task-1-rereview-inheritance.go`, run from `services/shared` with `go run` and using only dummy data in a verified test-owned temporary directory that was removed afterward. The fixture gives Everyone non-inheritable WRITE_DAC on the parent, gives the file a current-user-only unprotected DACL, opens it with the real OpenAppend helper, then uses that permitted parent security operation to add an inheritable Everyone grant. Output:

```
Check before=<nil>
OpenAppend=<nil>
Check after inherited grant=protected path grants access to another identity
append after inherited grant=<nil>
```

The fixture runs as the current user to perform the same DACL operation explicitly granted to Everyone; it does not create another account or claim live foreign-owner coverage. Windows ACL inheritance and its protected-DACL control are documented by Microsoft in [Automatic Propagation of Inheritable ACEs](https://learn.microsoft.com/en-us/windows/win32/secauthz/automatic-propagation-of-inheritable-aces).

Fix: require SE_DACL_PROTECTED for an existing object accepted as a protected read/append file, or establish an equivalent stable inheritance boundary. Reject rather than silently narrow an existing append file, since prior handles cannot be revoked. All files created by privateDescriptor already request D:P. Add the reproduced parent-DACL-change case as a regression; it must fail before append can expose future state. Keep broad traversal ancestors supported and unchanged.

### P1: Create Unix lock parents before acquiring filesystem locks

Locations: `services/nvpair-codex-worker/journal.go:45-50` and `services/nvpair-codex-supervisor/taskindex.go:84-89`.

Removing the common EnsureDir call moved parent-directory creation after lock acquisition. On Unix, acquireJournalLock and acquireTaskIndexLock open `path + ".lock"` directly with O_CREATE. Thus `NewJournal(<existing-temp>/missing/tasks.jsonl)` and `OpenTaskIndex(<existing-temp>/missing/tasks.jsonl)` now return ENOENT before OpenAppend can create `missing`. This breaks the constructors' prior first-use behavior, including a standalone Worker configured with a new state directory and a Supervisor index under a missing directory. Windows named mutexes do not touch the filesystem and therefore do not expose this regression in the executed Windows suites.

Fix: prepare the parent before opening the .lock file in each Unix lock helper (or another Unix-only path), preserving existing Unix ancestor behavior. Do not restore common Windows EnsureDir calls that narrow existing ACLs before append validation. Add constructor regression cases whose parent is genuinely absent. Linux/macOS compilation alone does not prove this behavior; this reviewer did not execute Unix binaries. Root has identified WSL as a possible native Linux execution venue for the correction tests.

## Stored-artifact interaction requested by controller

ArtifactStore.StageHandoff now uses protected CreateTemp/Publish. ArtifactStore.Read still uses its existing Lstat plus openArtifactSource, whose Windows opener prevents only final-component reparse traversal and does not pin intermediate directories or validate the stored file ACL. It therefore does not gain the new helper's protected-read guarantee. Using protectedfile.Open for the **stored output** is a small consistent integration change; leave **user-workspace input** on its separate sandbox/source opener. I have not promoted this unchanged read path to a third newly introduced blocker in this scoped correction review or claimed a separately reproduced exploit. Existing broad-directory handles and replacement remain the pertinent threat model if a broader end-to-end stored-artifact guarantee is claimed.

## Verification and limits

- Reviewer ran `go test ./protectedfile -count=1 -v`: PASS, 0.277s, with one explicit capability SKIP.
- `TestWindowsRejectsUntrustedOwnerBeforeProtection`: SKIP because the current token cannot assign the foreign owner (ERROR_INVALID_OWNER). This is untested live-owner behavior, not a pass.
- `TestWindowsForeignOwnerDescriptorCannotBeProtected`: PASS; this verifies the native descriptor at the mutation boundary, not foreign ownership of a real filesystem object.
- Reviewer ran the focused native inheritance fixture above and reproduced the remaining Windows defect.
- Reported Worker, Supervisor, shared, and seven Codex cross-process results were treated as supplied implementation evidence, not rerun here. No competing full suite was started.
- No change to the prior three-service version dependency inventory: Worker, Supervisor, and broker. Controller owns version integration.
