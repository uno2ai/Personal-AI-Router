<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 2 independent spec and quality review

Reviewed range: `8eccc1d..5b3a8aa` (24 files), in `<REPO>/.validation/publish`.

Verdict: **Accept Task 2 for the controller's final integration and publication checks.** No concrete unresolved Critical or Important finding was identified in this scoped change. This is not authorization to merge main.

## Strengths

- The Desktop bridge uses a single canonical broker location, structured arguments, hidden process creation, bounded input/output and a 15-second timeout. It sends write content through stdin and discards raw subprocess errors and stderr. Missing broker binaries fail closed with a rebuild/reinstall diagnostic. The one-shot broker dispatch runs before logger initialization and worker supervision; it introduces no JSON-RPC drift or alternate worker launch path.
- Managed configuration, runtime descriptors, and management registry reads use strict protected-file reads. Main Codex input uses an explicitly separate reader. The new Windows reader checks the actual opened owner, retains the existing pinned ancestor chain, rejects reparses, and does not alter the input ACL. It does not weaken the accepted Task 1 strict reader.
- Main registration derives its fingerprint, transformation, and backup from the same input read. Both configuration content and backups use native private staging. Unrelated MCP entries and the existing ownership/concurrency guard are retained. The implementation removes the old Desktop chmod-best-effort secret writes without adding a fallback.
- The Unix parent-preserving write policy factors the existing staging implementation instead of copying it. It preserves existing containing-directory modes and creates missing directories privately. The owned-input reader checks the opened regular file's effective-user ownership and final symlink without chmodding external configuration or its parents.
- Native E2E fixtures use the selected build's same broker writer. The extracted process harness retains early records, reports spawn/exit/parse failures without response bodies, bounds its pending line and record queue, and bounds termination of fixture-owned child processes. Failure assertions no longer dump model result objects or stderr. The macOS Electron restart scenario remains an explicit Windows skip.
- Security tests exercise real built broker binaries, real Windows DACLs and directory junctions, inherited Main configuration, strict managed-input rejection, private backups, metacharacter paths, oversized input rejection, and staging cleanup. The harness tests use actual subprocesses. The unnecessary Codex exports were removed, and native E2E source now participates in typechecking.

## Issues

### Critical (must fix)

None identified.

### Important (should fix)

None identified.

### Minor

None raised. Existing behavior outside this patch and cosmetic preferences were not converted into findings.

## Evidence and scope

Read the Task 2 brief/report, complete changed implementation and test files, the relevant shared protected-file interactions, CONTRIBUTING.md, Developer Guide, and accepted Task 1 final review. Task 1's settled security design was inspected only where the new Task 2 entrypoints depend on it.

Inspected the supplied logs directly:

- `task2-unit-verified.log`: 45 files passed; 238 tests passed, 2 skipped. Includes all 12 Codex configuration tests and all 6 native-process tests.
- `task2-desktop-verified-red.log`: 5 failures against the earlier implementation, including missing junction rejection, managed-input acceptance and actual-DACL failures. These are meaningful regression failures, not Unix-mode-only assertions.
- `task2-native-process-green.log` and `task2-helper-green.log`: focused early-event/exit and native helper green evidence; the later full unit log covers the expanded harness suite.
- `task2-protectedfile-final.log`: passing inherited-input preservation/pinned-ancestor test and accepted protected-file regressions. Both live foreign-owner tests explicitly skip because the current token cannot assign the foreign owner. The deterministic foreign-owner descriptor test passes.
- `task2-unix-green.log`: all 5 selected Linux protected-file tests pass, including preserving existing parent modes, creating private parents, owned-input behavior, and sticky/symlink traversal compatibility.
- `task2-typecheck-verified.log`, `task2-lint-verified.log`, `task2-dead-code-final.log`, and `task2-contracts-final.log`: three typecheck targets complete, lint reports 0 errors/25 warnings, dead-code reports zero findings, and service contracts report fresh/no drift.

I independently ran `git diff 8eccc1d..5b3a8aa --check` successfully. The checkout was clean when inspected. No source, index, HEAD, branch state, installed account configuration, or dependency metadata was changed. No subagent or competing service suite was launched.

## Assessment

**Ready for final controller validation: Yes.** The scoped implementation satisfies the approved Windows protection and Desktop/native-harness requirements with meaningful native regression evidence. The controller still owns the final whole-branch review, all-module/build/native model verification, service version audit, redacted publication evidence, and signed branch push for maintainer macOS review. Native macOS execution and live foreign-owner paths are not represented as passing coverage.
