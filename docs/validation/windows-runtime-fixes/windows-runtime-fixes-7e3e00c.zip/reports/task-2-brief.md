# Task 2: Windows Desktop protected configuration and native E2E

Workspace: <REPO>/.validation/publish on codex/windows-runtime-fixes. User authorizes Windows repairs, tests, signed commits and branch push for macOS review; do not merge main. Controller handles final all-module run/build/native E2E, versions, publication and push. Preserve original checkout changes. Work sequentially, no subagents. Read repo AGENTS/CONTRIBUTING and relevant skills; user already approved this bounded repair workflow, so no routine permission stop.

## Own this scope

Desktop Codex config-store, codex-manager, mcp-registration, new focused protected-file bridge if needed; modular codex-config and e2e-user-data-path tests; native codex-desktop E2E harness; a one-shot nvpair-ui-broker protected-file CLI helper and tests/docs. Related build/test documentation as necessary. Root owns services/versions.json and untracked implementation plan: leave these unstaged. SPDX headers were already restored in all baseline missing files, commit dec8ea2. Add SPDX to new files.

## Architecture and security contract

Do not duplicate native Windows security in PowerShell/C#. Reuse nvpair-shared/protectedfile through a focused broker one-shot helper BEFORE normal broker initialization/supervision. Electron continues to launch only the broker. Use structured argv and bounded stdin payload (no secret argv, logs, prompts or response bodies); return only necessary read bytes to the caller, not logs, and metadata-only errors. No new JSON-RPC method needed; no new dependencies, no arbitrary shell evaluation.

Go APIs after Task1: WriteFile(path, bytes) for private atomic replacement; Open(path) returns *File (io.Reader + Close); OpenAppend for journals; CreateTemp/Publish for streaming. Windows opens each component relative to its parent handle, pins the chain without delete sharing, checks actual object owner/reparse/DACL, and creates private files with their SD at creation. Existing protected files must have SE_DACL_PROTECTED; private ACEs alone can be broadened through inheritance. Windows traversal/containing directories need not be private and their ACLs are not rewritten. Ordinary AppData/E: ancestors must work unchanged. Always close returned File to release the pinned chain. Do not Check(path) and then reopen by pathname.

Keep managed config/credential reads strict. External Main Codex config.toml may already exist with inherited ACLs. A read/preview must not silently Protect/chmod it or its parents. If a distinct owned-input read primitive is needed, coordinate with controller and implement actual-handle owner/reparse checks with a clear contract; do not relax protectedfile.Open. Applying registration must preserve unrelated entries and privately stage both new content and backup, never append new secrets through an old broad object. Preserve existing Unix modes and /var or sticky /tmp traversal compatibility.

## Required work and tests

1. Baseline on supported Node already reproduced: 225 pass, 3 fail, 2 skip. Two failures assume Unix mode bits; one symlink fixture fails EPERM on Windows.
2. Replace Desktop chmod-best-effort secret/config writes with Go-backed Windows protection. Meaningful native ACL tests must inspect the actual DACL, exercise names with spaces/metacharacters, reject junction traversal, and establish private creation before writing bytes. Test initial save, backup/update, failure cleanup, and existing Main config preservation; include the inherited-ACL existing Main config compatibility case. Keep parsing logic testable and broker path resolution canonical; a missing broker is an actionable failure, no unsafe filesystem fallback.
3. Unprivileged Windows path-escape test should create a directory junction (fs.symlinkSync(..., 'junction')); Unix uses directory symlink. Assert realpath escape rejection. Do not skip security assertion merely to get green.
4. Native E2E fixture config must use the shared Desktop protected writer. Improve JsonLineProcess event/error handling (early events are currently dropped), actionable metadata-only failures, and bounded owned-process cleanup. Do not dump model text or credentials on failed assertions. Preserve macOS-only Electron restart test as an explicit Windows skip unless actually ported and verified; controller is not requesting that expansion.
5. Baseline dead-code check has four Codex-only findings: config-store CODEX_CONFIG_SCHEMA_VERSION and validateCodexConfig exports; mcp-registration renderManagedMcpRegistration and McpRegistrationSnapshot exports. Remove unnecessary exports/unused wrappers. No new TS casts, :any or unknown signatures. Static imports, @/ across directories.
6. Run new focused tests red/green, full Desktop unit/typecheck/lint/contracts/dead-code checks and broker helper Go tests. Report exact passes/fails/skips. Controller runs final package build and native model E2E, so don't compete with those or alter installed Codex/account config.

## Tooling and evidence

For npm prepend PATH with <REPO>/.validation/tools/node-v26.0.0-win-x64 (Node26.0.0/npm11.12.1). Current default Node24 is below repository minimum25.5. desktop/node_modules is a junction to the already installed unchanged-lockfile dependencies; do not npm ci/reinstall or mutate metadata through it. Use npm.cmd/npx.cmd from PowerShell. Unit helper integration must build or deterministically locate a fresh broker, not a stale packaged binary. Keep generated binaries ignored/local.

Go1.26.4 available. Logs: <REPO>/.validation/fix-logs/task2-*.log; preserve every attempt, do not overwrite red logs with green. Report: .validation/fix-reports/task-2-report.md. Read Task1 report for exact final API and remaining live foreign-owner fixture capability skip. Sign off a focused explicit-files commit and return hash/report for independent scoped review; do not push. Final validation and log publication belong to controller.
