<!--
SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
SPDX-License-Identifier: Apache-2.0
-->

# Task 1: Windows Go runtime repair report

Commit: `5ef8a22` (signed off), branch `codex/windows-runtime-fixes`. No push. No version-file changes. Scope extended by controller to include the fake app-server fixture's missing protocol response. No desktop or discovery edits.

## Implemented

- Added `nvpair-shared/protectedfile`: `EnsureDir(path) error`, `Protect(path) error`, `Check(path) error`, `WriteFile(path, data) error`. Windows uses a protected DACL allowing current process user SID, SYSTEM, and Builtin Administrators; rejects null DACLs, untrusted owners, other effective allow ACEs, unsupported ACE types and final reparse points. Unix enforces 0700 directory / 0600 file writes and rejects group/world access. EnsureDir protects its target and creates/protects missing ancestors; it does not change existing ancestors outside its target. WriteFile privately stages, syncs and replaces files; its containing directory is protected before temporary creation or secret data writes.
- Managed config and Supervisor credential readers validate both file and containing directory before reading. Desktop must protect config parent and config before its bearer-token write. No JSON-RPC or control protocol changes.
- Applied protection to Worker state/journal/artifacts, isolated Codex home/authentication, credentials and shared runtime descriptors; Supervisor task index and management registry. Cached isolated auth is reused only while its protection remains valid.
- Added shared Windows mutex owner: acquisition, wait, release and handle close occur on one locked OS thread; cross-goroutine Close is idempotent and waits for actual handle closure. Nonblocking waits distinguish contention from an abandoned/released object. Journal, task index and workspace lease wrappers use it. Workspace identity is hashed directly (volume/file identity), independent of each Worker's current directory.
- Native Windows execution accepts .exe and resolves codex.ps1/codex.cmd installation locations to architecture-specific native npm optional package executables (nested or hoisted npm layouts). Unsupported scripts and missing native binaries produce actionable errors. Shell text is never parsed or invoked and argument boundaries remain exec.Command arguments. Resolution applies to both managed and standalone child launches.
- Windows app-server child starts CREATE_SUSPENDED, joins its kill-on-close job, and only then resumes using documented Toolhelp / ResumeThread APIs. Both Probe and task callers route verification failure through terminateAndWait, which removes the job-map entry, terminates/closes the assigned job, and waits for the process; unassigned failures kill the process and cleanup closes the unassigned job.
- Corrected the broker fixture's absolute path. Registered cross-process cleanup immediately after process startup, with idempotent stop/one Wait; Windows kills the owned Worker process whose kernel job handles then close. Supervisor shutdown closes its input first. No process-name or global worker termination.
- Cross-process fake app-server had no config/read response. Its log stopped at initialize, initialized, config/read, so production isolation verification could not reach turn/start. Added the faithful empty active config-layers response, preserving production isolation checks.
- Documented Windows native executable and private state behavior in Worker/Supervisor README files. Fixed existing missing SPDX headers in task-index lock files.

## Evidence

Logs are in `<REPO>/.validation/fix-logs/`, names below.

Original reproduced failures:
- `task1-baseline-nvpair-codex-worker.log`: Windows mode assertion and managed config-revision shutdown fails with mutex not owned by caller.
- `task1-baseline-nvpair-codex-supervisor.log`: 4 local credential tests fail because Windows reports 0666.
- `task1-baseline-nvpair-ui-broker.log`: /protected/... is not an absolute Windows path.
- `task1-mutex-red.log`: deterministic cross-thread release fails with mutex not owned by caller, then `task1-mutex-green.log` passes.
- `task1-executable-red.log`: npm scripts incorrectly returned unchanged and unsupported script accepted; new resolver tests pass in Worker suite.
- `task1-child-job-red.log`: helper executes before assignment. Fixed test additionally verifies job close kills the process and its descendant.
- `task1-cross-process-first.log`: fake fixture tasks time out and Fatal leaves restart Worker running. The exact test-owned orphan was stopped after identifying its path/PID and inspecting metadata-only state and fake method log.

Final executed native Windows tests:
- `go test ./...` in Worker: PASS (`task1-final-audit.log`, 6.277s; prior dedicated `task1-worker-final.log`).
- `go test ./...` in Supervisor: PASS (`task1-supervisor-final.log`, 0.646s, also final audit).
- `go test ./...` in broker: PASS (`task1-broker-final.log`, main 15.171s plus relay/workloadstore).
- `go test ./codexruntime ./protectedfile ./winmutex` in shared: PASS (`task1-final-audit.log`). Latest ACL/mutex regression rerun PASS (`task1-shared-final.log`). ACL tests apply and reject Everyone, Builtin Users, Authenticated Users and null DACLs, then verify protected acceptance and private directory inheritance before any write. Mutex test holds kernel object across killed owner to exercise WAIT_ABANDONED and reacquisition.
- Selected Worker lifecycle regressions run with `-count=3`: PASS (`task1-lifecycle-repeat.log`). Covers release from different locked OS thread, cross-process/cross-journal contention from different working directories, managed config revision, suspended child/job assignment and descendant termination. The helper-only top-level test skips normally; its subprocess executes in the real contention test.
- All 7 Codex cross-process tests: PASS (`task1-cross-process-final.log`, 16.838s including TestMain builds): bounded delegation, idempotent restart, stale retry fence, blocked approval, scoped cancellation, unsafe path rejection, managed Worker restart/shutdown preserving an independently running Worker.
- `git diff --check` / staged check: PASS. Repository SPDX scan reports preexisting missing headers outside this change; the remaining owned Unix task-index header was corrected afterward. Controller owns the remaining global header gate.

Compile-only compatibility (not native execution): Worker and Supervisor test binaries compile for linux/amd64 and darwin/arm64; protectedfile Unix tests compile for linux/amd64 (`task1-cross-compile.log`, successful commands, no diagnostics). .test files beside the logs are compile artifacts, not evidence of execution, and should not be published as logs.

## Integration and limits

Bump affected service versions: nvpair-codex-worker and nvpair-codex-supervisor; nvpair-ui-broker also imports the changed shared codexruntime package, so include its patch bump when staging compiled outputs. Controller should verify the dependency/version inventory during the full build.

No native model task or Electron UI was run by this subtask; controller's native Codex readiness/delegation and Desktop tests remain the integration evidence. Own-only shutdown is demonstrated at the actual managed-control Worker process layer with an independent Worker, not claimed as an Electron UI test. Linux/macOS test execution and Windows arm64 execution were not performed. No network/discovery behavior was changed. ACL trust deliberately includes SYSTEM and Administrators; same-user malicious processes and machine administrators remain inside the trust boundary.

References consulted: Microsoft mutex objects / abandoned owner semantics and Windows job objects documentation; installed npm Codex entrypoint confirmed current nested platform-package executable layout.


## Review fix round 1 (supersedes initial path-check implementation)

Signed commit `e4233f8`: Pin Windows protected file operations to inspected handles.

The reviewer found that final-component checks missed intermediate junctions and that DACL replacement without an owner check left another owner in control. The Windows implementation now opens each directory as a single relative component with NtCreateFile RootDirectory, checks reparse attributes on the actual handles, and retains ancestors through each operation. All new directory/file objects receive a protected security descriptor at creation. Directory handles include FILE_LIST_DIRECTORY and omit FILE_SHARE_DELETE: a failing regression proved that attribute-only handles do not enforce the intended sharing exclusion, so that access detail is deliberate. Existing broad traversal ancestors are pinned rather than rejected by an ACL allowlist or altered. The normal host AppData/Temp and E: paths were used for tests; no host ACLs were changed and tests were not relocated to bypass this issue.

Protect checks the native owner descriptor before generating/installing a private DACL through SetSecurityInfo on that same handle and verifies the resulting owner/DACL. Config and credential readers use Open, retaining checked file and directory handles throughout decoding; they no longer do Check(path) followed by os.Open(path). They do not require separate Check(parent): Windows ancestry integrity is supplied by handle-relative traversal and retained handles, while the actual file must have a trusted owner/private DACL.

Journal and task-index fields now retain protectedfile.File and close it with their ordinary lifecycle. OpenAppend rejects existing broad ACLs and hard-link aliases without modifying or appending to them. Removed Journal/TaskIndex pre-EnsureDir and managed state-root narrowing: directory ACL propagation must not make a previously broad journal appear safe before its initial check. Existing replay fixtures now explicitly create private files. Native app-server isolated-auth writes, credentials, runtime descriptors and staged artifacts use the protected writer/publication APIs for the full write-to-rename lifetime. Failed unpublished Windows stages are removed by their actual handle before release.

Final API contract for Desktop/broker reuse:

- WriteFile(path, data) error: create missing directories privately, pin traversal handles, create private temporary file, write/sync, publish with handle-relative rename, close. Existing traversal parents are not rewritten by this writer. Windows creation validates the containing target directory's owner. Replacing an old file publishes a fresh privately owned object; it never appends to or narrows that old file.
- Open(path) (*File, error): safe regular-file reader; callers must defer File.Close. Use io.LimitReader for the calling protocol's size bound. Missing-file errors support errors.Is(err, os.ErrNotExist).
- OpenAppend(path) (*File, error): safe new/private-existing journal handle; callers retain it until lifecycle Close. Broad existing files are rejected, not migrated by DACL narrowing. Windows multi-hardlink files are rejected.
- CreateTemp(directory, pattern) (*File, error), File.Publish(path) error: for bounded streaming artifacts; sync and publish while the File is still open, then Close. Publication must remain in the pinned containing directory.
- File embeds os.File and implements Close, retaining/releasing the needed directory handles. Do not call File.File.Close directly.
- EnsureDir and Protect remain explicit protection APIs, with actual-handle owner checks on Windows. They are not substitutes for the operation-lifetime writer/read APIs: changing a directory DACL cannot revoke historical handles.

Unix path traversal behavior remains unchanged, including intermediate /var-style symlinks and sticky /tmp-style ancestors. Added a compile-tested Unix fixture checking both. New Unix Open/OpenAppend reject final symlinks through O_NOFOLLOW; existing Unix append files must remain private.

Round-1 evidence (`task1-fix1*` logs, original round logs preserved):

- `task1-fix1-red.log`: intermediate junction accepted, secret written through it, and read-side Check accepted it before repair. Live owner assignment attempt reports SKIP because this token cannot assign Builtin Users as owner (ERROR_INVALID_OWNER); no account, privilege or host ownership change attempted.
- `task1-fix1-handle-regressions.log`: exposed the attribute-only-directory-handle sharing gap. `task1-fix1-handle-regressions-green.log`: passes after FILE_LIST_DIRECTORY access. Covers actual intermediate junction, stage/read parent rename blocking, refusal when an ancestor already has a deletion handle, broad append rejection without byte/ACL mutation, hard-link append rejection, and failed-stage cleanup.
- `TestWindowsForeignOwnerDescriptorCannotBeProtected` PASS: uses a native Windows security descriptor with foreign owner plus current-user full access, through the exact descriptor-generation boundary used before Protect mutates a DACL. Live foreign-owner filesystem fixture remains SKIPPED for insufficient token capability; native other-owner EnsureDir/Protect behavior is not falsely claimed as executed.
- `task1-fix1-notexist-red.log` / `-green.log`: missing native NTStatus did not satisfy os.ErrNotExist; mapped through NTStatus.Errno, now passes. Final shared protection regression suite PASS.
- `task1-fix1-worker-final.log`: full Worker module PASS (6.092s).
- `task1-fix1-supervisor-final.log`: full Supervisor module PASS (0.622s).
- `task1-fix1-shared-final.log`: protectedfile/codexruntime/winmutex PASS; newest missing-file regression rerun in `task1-fix1-notexist-green.log` PASS.
- `task1-fix1-cross-process-final.log`: all seven Codex cross-process tests PASS (13.809s including builds), including independent Worker preservation across managed restart/shutdown.
- `task1-fix1-cross-compile.log`: Worker/Supervisor linux/amd64 and darwin/arm64 compile-only success, plus protectedfile Unix test binary linux/amd64. No native Unix execution claimed.
- `task1-fix1-commit.log`: staged diff check passes and signed commit. Controller-owned versions.json was explicitly left unstaged.

Remaining integration boundary: Desktop should call the Go protected writer/reader via the planned narrow broker stdin helper, rather than reimplementing these Windows guarantees in TypeScript or PowerShell. Root owns full module matrix, packaged native Codex integration, versions and final publication. The live untrusted-owner fixture requires a suitably privileged Windows test environment; it remains a transparently reported capability gap, with the production mutation boundary covered using native descriptors.

## Review fix round 2

Signed commit `3f0c299ca9696f8ae3b191482e98f72d94548cee`: Reject inheritable Windows state ACLs and restore Unix first use.

The reviewer confirmed that a currently private but inheritance-enabled Windows DACL could acquire broad rights later when an ancestor ACL changed, even while the append handle remained open. `checkSecurity` now requires `SE_DACL_PROTECTED` for all accepted existing objects. `Check`, `Open`, and `OpenAppend` therefore reject such files before reading or appending. The regression supplies a parent with Everyone WRITE_DAC and an initially private unprotected child, verifies rejection, then privately replaces the child using `WriteFile`, opens it for append, broadens the parent to inheritable Everyone full access, and verifies the actual open child remains private before continuing its write. Only disposable test directory ACLs were changed; no host or profile ACLs were modified.

API clarification for Desktop/broker: signatures from round 1 are unchanged. Existing Windows files accepted by `Check`, `Open`, or `OpenAppend` must have DACL inheritance disabled, in addition to trusted ownership and private access. Files created through `WriteFile`/`CreateTemp`/`OpenAppend` already receive protected DACLs at creation. No separate parent `Check` is required; pinned handle traversal remains the ancestor integrity mechanism. An inheritable existing file should be privately replaced through the writer where migration is appropriate, not accepted for append by narrowing its ACL.

The Unix Journal and TaskIndex lock helpers now prepare their parent directory before opening the filesystem lock. This fixes missing-parent first use without restoring the Windows pre-EnsureDir that could narrow an unsafe append file's ACL. Added constructor regressions run against real Linux `/tmp` paths in WSL Ubuntu. Stored `ArtifactStore.Read` now opens through `protectedfile.Open` and inspects that actual file handle; the separate user-workspace artifact input opener is unchanged.

Round-2 evidence (`task1-fix2*` logs; preceding logs preserved):

- `task1-fix2-inheritance-red.log`: newly added native Windows test fails because `Check`, `Open`, and `OpenAppend` accept the unprotected DACL. `task1-fix2-inheritance-green.log`: full native Windows protectedfile suite passes, including rejected inheritable state and ongoing append protection under parent ACL mutation.
- `task1-fix2-artifact-red.log`: stored broad-ACL artifact was readable. `task1-fix2-artifact-green.log`: actual protected-handle read rejects it, and the Windows missing-parent Journal test passes.
- `task1-fix2-worker-wsl-red.log` and `task1-fix2-supervisor-wsl-red.log`: actual Linux constructor tests fail with ENOENT opening the nested missing-parent `.lock` file. Corresponding `-green.log` files pass after Unix-only parent preparation.
- `task1-fix2-worker-wsl-journal-final.log`: all 5 selected Journal tests pass in WSL Linux.
- `task1-fix2-supervisor-wsl-taskindex-final.log`: all 5 selected TaskIndex tests pass in WSL Linux.
- `task1-fix2-worker-final.log`: native Windows full Worker module `go test -count=1 ./...` passes (6.170s).
- `task1-fix2-supervisor-final.log`: native Windows full Supervisor module passes (0.611s).
- `task1-fix2-shared-final.log`: native Windows protectedfile and codexruntime packages pass (0.289s and 0.303s).
- `task1-fix2-commit.log`: working/staged diff checks pass and signed explicit-file commit is recorded. Controller versions.json and the untracked plan remain excluded.

The WSL evidence is actual execution of crosscompiled linux/amd64 test binaries through `wsl.exe -d Ubuntu --exec`, with quoted test flags; it is not compile-only evidence. macOS and Windows arm64 execution remain outside this subtask. The existing live foreign-owner fixture still skips with ERROR_INVALID_OWNER because this token cannot assign the requested owner; the native foreign-owner descriptor mutation-boundary test remains passing. No other round-2 regression was skipped. Cross-process tests were not repeated for this bounded correction; the seven-test passing round-1 evidence remains available and the controller owns the final full matrix and Desktop/native Codex integration. Affected binary versions remain Worker, Supervisor, and broker (shared package consumers), with version edits owned by the controller.

## Final integration test fixture follow-up

Signed test-only commit `9225e384d679174be4db8a49ba25170430b23c38`: Exercise Codex path security with unprivileged Windows junctions.

Before this change, both `TestArtifactStoreRejectsPathEscapeSymlinkAndOversize` and `TestWorkspacePolicyRejectsTraversalAndSymlinkEscape` skipped in their entirety on native Windows because this account lacks symlink privilege. `final-fixtures-before.log` reproduces both skips. The Worker now uses an unprivileged native Windows directory junction fixture (CreateFile + FSCTL_SET_REPARSE_POINT on a disposable empty directory), matching the proven shared-package fixture. No shell command construction or host changes are involved. Unix continues to use a directory symlink. Each link-dependent assertion runs in its own subtest, so any Unix capability skip cannot suppress traversal, platform-native absolute-path, slash-absolute-path, or oversize cases. Platform-native absolute fixtures use filepath.Join(outside, "secret.txt"). The artifact link assertion now requires the specific link-component rejection, so a missing file or byte-limit error cannot masquerade as path protection; its outside fixture is below the size limit.

Evidence:

- `final-fixtures-before.log`: 2 selected top-level tests SKIP due missing Windows symlink privilege.
- `final-fixtures-after.log`: intermediate test run exposed that link rejection uses the existing link-component error, not ErrUnsafeArtifactPath. Only the test assertion was corrected to the actual production contract; no production change.
- `final-fixtures-windows-green.log`: both selected top-level tests PASS, all 9 child cases PASS, zero skips (including both Windows junction cases).
- `final-fixtures-worker-full.log`: complete native Windows Worker go test -count=1 -json ./... PASS, 6.445s. `final-fixtures-worker-count.log`: 56 top-level PASS, 1 SKIP, 0 FAIL. The sole skip is TestWorkspaceLeaseProcessHelper, intentionally activated as a subprocess by the real process-contention test.
- `final-fixtures-linux-captured.log`: actual WSL Ubuntu execution of the compiled linux/amd64 tests, with stdout and exit 0 captured by the controller. Both top-level tests and all 9 child cases PASS, zero skips; Unix symlink behavior is exercised. The earlier `final-fixtures-linux.log` transcript omitted stdout and is not the authoritative execution log.
- `final-fixtures-commit.log`: explicit four Worker test files staged, diff check clean, signed commit. Working tree clean afterward. No production changes, dependencies, version changes, or other test scope added.

These two formerly skipped top-level tests now pass on Windows. The controller's prior all-module count should therefore gain 2 passes and lose 2 skips when aggregating with this Worker rerun; this subtask does not claim to have repeated the full 18-module matrix. Other reported native ownership-fixture capability limits remain unchanged.

## Native model integration correction

Signed commit `7e3e00cdc044565044f24aa8f269e0fcfcc95895`: Enable native Windows sandbox for isolated Codex tasks.

The controller's packaged native test at 9225e38 reached ready and delegated successfully but failed after about nine seconds. This was not a process crash or timeout. Metadata-only rerun `native-debug-01-journal.log` established accepted -> starting -> running -> waiting_approval -> blocked, with a child and native thread created. Temporary diagnostic build `native-debug-02-approval.log` classified the native request as item/commandExecution/requestApproval for a PowerShell/pwsh command containing git status. It had no reason or network-approval context and included an exec-policy amendment proposal. Neither prompts, command strings, model text, response bodies, nor authentication were logged.

PAIR's isolated CODEX_HOME copies authentication but intentionally omits Main's configuration. On this Windows installation Main explicitly selected the unelevated native sandbox; the isolated app-server had no Windows sandbox selected. Version-pinned upstream code confirms that read-only policy without a Windows sandbox cannot execute unmatched commands without approval. The Worker correctly declined the approval request, causing the blocked terminal result.

The fix appends the structured arguments `-c` and `windows.sandbox="unelevated"` only to isolated Windows app-server commands. This enables Codex's native restricted-token enforcement without importing Main's extensions/configuration or requiring elevated machine-wide setup. Thread/turn read-only or workspace-write policy and on-request approval handling are unchanged; no approval is automatically granted and no unsandboxed execution is selected. Unix and non-isolated commands retain their exact previous arguments. Existing unreleased Worker version 0.1.1 remains per controller instruction; only the Worker compiled output changed in this correction.

Mode limitation: Codex's unelevated mode uses restricted tokens and ACL-based filesystem boundaries, with environment-level offline controls. Its network isolation is weaker than the elevated sandbox, which uses dedicated users/firewall policy. This is now documented in the Worker README. No host firewall/account/Main configuration was modified by this repair. Enterprise native sandbox requirements remain enforced by Codex; this adapter does not bypass them.

Official supporting evidence:

- https://raw.githubusercontent.com/openai/codex/rust-v0.152.1/codex-rs/core/src/exec_policy_windows_tests.rs : version-pinned tests `read_only_windows_sandbox_runs_unmatched_commands_under_sandbox` and `read_only_windows_policy_without_sandbox_backend_still_requires_approval` distinguish RestrictedToken/Elevated from Disabled.
- https://developers.openai.com/codex/windows/windows-sandbox (redirects to https://learn.chatgpt.com/docs/windows/windows-sandbox): documents `windows.sandbox` modes and restricted-token versus elevated enforcement. Consulted 2026-09-08.

Verification and artifacts:

- `native-debug-03-argv-red.log`: new isolated-child command regression fails because the Windows sandbox selection is absent.
- `native-debug-04-argv-green.log`: regression passes with the explicit native sandbox argument. It checks the complete isolated argument sequence and verifies non-isolated arguments remain unchanged.
- `native-debug-05-sandbox-native.log`: actual installed Codex 0.152.1 via the .ps1 launcher resolver completes the real read-only task through Worker + Supervisor MCP. 2 PASS, 1 macOS-only ownership E2E SKIP, duration 17.835s. Uses packaged 9225e38 broker/Supervisor plus the newly compiled Worker in `.validation/native-debug-cli-bin`; the original packaged output was not overwritten. The controller must rebuild the final installer and repeat against all-packaged final binaries.
- `native-debug-06-worker-full.log`: full native Windows Worker module passes with count=1 (6.335s), including approval-blocking and policy regressions.
- `native-debug-10-linux-argv-executed.log`: real WSL Ubuntu execution of crosscompiled linux/amd64 tests, with stdout and explicit exit 0 captured through Tee-Object. Both argument/isolation tests pass, verifying Unix argument behavior remains unchanged. Earlier `native-debug-07-linux-argv.log` transcript omitted native stdout and is not the authoritative execution log.
- `native-debug-08-typecheck.log`: all Desktop node/web/test typechecks pass, including E2E source.
- `native-debug-09-commit.log`: explicit four-file signed commit, diff check clean, tree clean.

Temporary approval classifications were completely removed from Go source before the successful native run. No general stdout/stderr/payload logging was introduced. The E2E failure path retains terminalState and at most 16 journal entries containing only sequence, kind, state, child/thread presence, and event kind; it does not include journal requests, handoffs, summaries, or event metadata. Existing process cleanup remains scoped to fixture-owned child handles. Native final installer validation and Windows Electron ownership UI coverage remain the controller's integration responsibilities; the macOS-only UI test is not reported as Windows coverage.
